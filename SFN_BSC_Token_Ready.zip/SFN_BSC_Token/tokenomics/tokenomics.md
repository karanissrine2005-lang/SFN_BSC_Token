# SFN_BSC Tokenomics

- **Total Supply:** 1,000,000 SFN
- **Allocation:**
  - 50% Public Sale
  - 20% Team & Advisors (Vesting)
  - 20% Rewards & Staking
  - 10% Reserve / Future Use
- **Use Cases:** Payments, Rewards, Governance
- **Burn & Mint Policy:** Controlled by smart contract, fully transparent
